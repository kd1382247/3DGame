﻿#pragma once

#include"../EnemyBase.h"

#include"Animation/CactasAnimationType.h"
#include"Animation/CactasAnimation.h"
#include"Parameter/CactasParameter.h"

#include"../../StateMachine/StateMachine.h"

class Cactas :public EnemyBase
{
public:

	Cactas() {}
	~Cactas()override {}

	void Init()override;
	void Update()override;
	void PostUpdate()override;

	void SetUpReference()override;

	void DrawDebug()override;

	bool IsAttack()const { return m_attackFlg; }
	bool IsLaunch()const { return m_launchFlg; }

	// パラメータのゲッター
	int GetMaxHP()const override { return m_parameter.GetParam().m_maxHP; }
	float GetTurnSpeed()const override { return m_parameter.GetParam().m_turnSpeed; }
	float GetMoveSpeed()const override { return m_parameter.GetParam().m_moveSpeed; }

	void PlayAnimation(CactasAnimationType type);
	void RePlayAnimation(CactasAnimationType type);


	bool IsAnimationFinished()const { return m_animation.IsFinished(); }

	void StartAttack();
	void EndAttack();

	void UpdateLaunch();

	// 攻撃判定
	void UpdateAttackCollision();

	void OnHit(const AttackInfo attackInfo) override;

private:

	void UpdateAnimation();

	void PlayWalkAnimation() override;
	void PlayIdleAnimation() override;

	void DrawParameterInspector() override;

	void SetAttackTiming();

private:

	// アニメーションクラス
	CactasAnimation   m_animation;

	// パラメータクラス
	CactasParameter   m_parameter;

	// ステートマシン
	StateMachine<Cactas> m_stateMachine;
};